# Sagittarius — Multi-Build Bundle

Sagittarius is the program family. The second word is the **Build Type** and the
number is that build type's **Build Version**:

```
Sagittarius Violet 1
Sagittarius Sapphire 3
Sagittarius Parallel 5
```

These are parallel branches, not one global version sequence. `Parallel 5` is
not "newer than" `Sapphire 3`; it is version 5 of the Parallel path.

Every installed build shares the Sagittarius quote pool, but each build has its
own presentation grammar and container personality.

## Included builds

| Build | Output design | Compression | Junk ratio | Chunk | Padding | Default scrypt |
|---|---|---:|---:|---:|---:|---:|
| **Violet 1** | mathematical operators, symbols and emoji; no ASCII alphanumerics in body | LZMA extreme when useful | 0.35x | 80 B | 128 B buckets | N=2^15 |
| **Sapphire 3** | mixed ASCII, operators, box glyphs and emoji | best of zlib/LZMA/bzip2/raw | 0.75x | 96 B | 256 B buckets | N=2^17 |
| **Parallel 5** | three-codepoint rare-Unicode tokens (Egyptian + Tai Xuan Jing + alchemical) | none | 1.50x | 48 B | 512 B buckets | N=2^16 |

Parallel 5 is intentionally huge: each 6-bit symbol is represented by three
supplementary-plane Unicode codepoints. Its visible UTF-8 form can therefore be
many times larger than a conventional Base64-style representation even before
its heavier junk profile is counted.

## Shared Sagittarius identity

All three builds use the same `QUOTES` pool and the same quote delimiter styles.
The actual quote positions, text choices, and delimiter styles are key-bound to
the authenticated metadata. Editing, moving, deleting or re-styling a quote is
rejected after successful authentication.

The build's visible grammar is also bound to its container. A Violet container
cannot simply be decoded and re-rendered using Parallel's alphabet and remain a
valid Sagittarius payload.

## Security core

The three builds share vetted primitives while domain-separating their keys:

```
password -> scrypt -> HKDF(build domain) -> AES-GCM content key
                                    \----> AES-GCM metadata key
```

The unusual Unicode/operator/emoji output is presentation, not cryptographic
strength. The package is an experimental custom container, not a standardized or
audited encryption format.

## Install

```bash
pip install -r requirements.txt
```

## Python use

```python
from sagittarius import Sagittarius

key = "correct horse battery staple"

violet = Sagittarius("Violet 1")
sapphire = Sagittarius("Sapphire 3")
parallel = Sagittarius("Parallel 5")

v = violet.encrypt("hello", key)
s = sapphire.encrypt("hello", key)
p = parallel.encrypt("hello", key)

# Decryption auto-detects the build from the payload.
plain = sapphire.decrypt_text(p, key)   # "hello"

print(Sagittarius.identify(v))  # Sagittarius Violet 1
print(Sagittarius.identify(s))  # Sagittarius Sapphire 3
print(Sagittarius.identify(p))  # Sagittarius Parallel 5
```

For faster local experiments/tests, override the KDF cost explicitly:

```python
engine = Sagittarius("Parallel 5", log2n=14)
```

## CLI

List builds:

```bash
python cli.py list
```

Encrypt:

```bash
python cli.py encrypt --build "Violet 1" --text "hello" --out payload.txt
python cli.py encrypt --build "Parallel 5" --file source.lua --out payload.txt
```

Decrypt (build is auto-detected):

```bash
python cli.py decrypt --file payload.txt --out recovered.lua
```

Omit `--key` to enter the key without echoing it in the terminal.

## Demo and tests

```bash
python demo.py
python test_all.py
```

`demo.py` encrypts the same Lua snippet through all three branches so their
outputs and visible sizes can be compared directly.
