"""Compatibility facade for the Sagittarius multi-build package.

Old-style imports continue to work:
    from Sagittarius import Sagittarius
"""
from sagittarius import *  # noqa: F401,F403
