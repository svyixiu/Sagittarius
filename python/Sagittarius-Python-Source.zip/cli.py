from __future__ import annotations

import argparse
from pathlib import Path
from getpass import getpass

from sagittarius import Sagittarius, BUILDS


def main():
    parser = argparse.ArgumentParser(description="Sagittarius multi-build container")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list", help="list installed Sagittarius builds")

    enc = sub.add_parser("encrypt", help="encrypt text or a file")
    enc.add_argument("--build", default="Sapphire 3", help="Violet 1, Sapphire 3, or Parallel 5")
    src = enc.add_mutually_exclusive_group(required=True)
    src.add_argument("--text")
    src.add_argument("--file")
    enc.add_argument("--key")
    enc.add_argument("--out")

    dec = sub.add_parser("decrypt", help="auto-detect build and decrypt")
    src2 = dec.add_mutually_exclusive_group(required=True)
    src2.add_argument("--payload")
    src2.add_argument("--file")
    dec.add_argument("--key")
    dec.add_argument("--out")

    args = parser.parse_args()

    if args.cmd == "list":
        for b in BUILDS:
            print(f"{b.name:24} compression={b.compression:8} junk={b.junk_ratio:<4} "
                  f"chunk={b.chunk_size:<3} pad=2^{b.pad_log2} token_width={b.token_width}")
        return

    key = args.key if args.key is not None else getpass("Key: ")

    if args.cmd == "encrypt":
        engine = Sagittarius(args.build)
        if args.text is not None:
            source = args.text
        else:
            source = Path(args.file).read_bytes()
        token = engine.encrypt(source, key)
        if args.out:
            Path(args.out).write_text(token, encoding="utf-8")
        else:
            print(token)
        return

    payload = args.payload if args.payload is not None else Path(args.file).read_text(encoding="utf-8")
    engine = Sagittarius("Sapphire 3")  # decryption auto-detects the actual build
    data = engine.decrypt(payload, key)
    if args.out:
        Path(args.out).write_bytes(data)
    else:
        try:
            print(data.decode("utf-8"))
        except UnicodeDecodeError:
            print(data.hex())


if __name__ == "__main__":
    main()
