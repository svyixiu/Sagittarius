from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from sagittarius import (  # noqa: E402
    Sagittarius, SagittariusError, BUILDS, QUOTE_SET,
    WRONG_KEY_GIBBERISH, decode_visible, encode_visible,
)
from sagittarius.core import _match_opener  # noqa: E402

KEY = "Sagittarius-Test-Key-2026"
WRONG = "Wrong-Key"
TEXT = "Sagittarius multi-build test.\nThe spaces are innocent.\n1234567890"
results = []


def check(name, ok):
    ok = bool(ok)
    results.append(ok)
    print(("PASS " if ok else "FAIL ") + name)


def rejects(engine, payload, key=KEY, mode="strict"):
    try:
        engine.decrypt(payload, key, mode)
        return False
    except SagittariusError:
        return True


check("three installed builds", [b.short for b in BUILDS] == ["Violet 1", "Sapphire 3", "Parallel 5"])

payloads = {}
for spec in BUILDS:
    eng = Sagittarius(spec, log2n=14)
    p = eng.encrypt(TEXT, KEY)
    payloads[spec.short] = p
    check(f"{spec.short}: identify", Sagittarius.identify(p) == spec.name)
    check(f"{spec.short}: text round trip", eng.decrypt_text(p, KEY) == TEXT)
    blob = os.urandom(4096)
    pb = eng.encrypt(blob, KEY)
    check(f"{spec.short}: binary round trip", eng.decrypt(pb, KEY) == blob)
    check(f"{spec.short}: wrong key rejected", rejects(eng, p, WRONG))

    raw, found = decode_visible(p, spec)
    check(f"{spec.short}: quotes present", len(found) >= 2)
    check(f"{spec.short}: quotes use shared pool", all(q in QUOTE_SET for _, q, _ in found))

    # Remove the first quote and ensure even decoy mode cannot suppress tamper detection
    qi = next(i for i in range(len(p)) if _match_opener(p, i) is not None)
    st = _match_opener(p, qi)
    op, cl = __import__("sagittarius").QUOTE_STYLES[st]
    qj = p.find(cl, qi + len(op))
    tampered = p[:qi] + p[qj + len(cl):]
    check(f"{spec.short}: quote deletion rejected in gibberish mode",
          rejects(eng, tampered, KEY, WRONG_KEY_GIBBERISH))

# Encoding grammars are visibly distinct.
check("Violet has no ASCII alphanumeric body tokens",
      all(not any(ch.isascii() and ch.isalnum() for ch in t) for t in BUILDS[0].tokens))
check("Sapphire has ASCII and non-ASCII body tokens",
      any(t.isascii() for t in BUILDS[1].tokens) and any(not t.isascii() for t in BUILDS[1].tokens))
check("Parallel tokens are three codepoints each",
      all(len(t) == 3 for t in BUILDS[2].tokens))

# Transport/build binding: a raw Violet container cannot be relabeled using Parallel's visual grammar.
veng = Sagittarius(BUILDS[0], log2n=14)
vpay = veng.encrypt("bind me", KEY)
vraw, _ = decode_visible(vpay, BUILDS[0])
relabelled = encode_visible(vraw, BUILDS[2], [])
check("cross-build re-encoding rejected", rejects(veng, relabelled, KEY))

# Distinct size/compression personalities on repetitive material.
material = "ABCD" * 3000
sizes = {}
for spec in BUILDS:
    eng = Sagittarius(spec, log2n=14)
    p = eng.encrypt(material, KEY)
    sizes[spec.short] = len(p.encode("utf-8"))
print("SIZE bytes", sizes)
check("Parallel output is substantially larger than Sapphire",
      sizes["Parallel 5"] > sizes["Sapphire 3"] * 3)
check("Violet and Sapphire do not have identical output sizes",
      sizes["Violet 1"] != sizes["Sapphire 3"])

# Automatic decryption works from any facade instance.
auto = Sagittarius("Sapphire 3", log2n=14)
for spec in BUILDS:
    check(f"auto-detect decrypts {spec.short}", auto.decrypt_text(payloads[spec.short], KEY) == TEXT)

print()
passed = sum(results)
print(f"{passed}/{len(results)} passed")
raise SystemExit(0 if passed == len(results) else 1)
