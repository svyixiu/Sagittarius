from __future__ import annotations

import hashlib
from dataclasses import dataclass
from .quotes import DELIM_CHARS


@dataclass(frozen=True)
class BuildSpec:
    family: str
    version: int
    magic: bytes
    tokens: tuple[str, ...]
    compression: str
    junk_ratio: float
    chunk_size: int
    pad_log2: int
    quote_density: int
    wrap_tokens: int
    log2n: int
    r: int = 8
    p: int = 1

    @property
    def name(self) -> str:
        return f"Sagittarius {self.family} {self.version}"

    @property
    def short(self) -> str:
        return f"{self.family} {self.version}"

    @property
    def domain(self) -> bytes:
        return f"Sagittarius/{self.family}/{self.version}".encode("utf-8")

    @property
    def token_width(self) -> int:
        widths = {len(t) for t in self.tokens}
        if len(widths) != 1:
            raise RuntimeError("build tokens must have one fixed codepoint width")
        return next(iter(widths))


def _check_tokens(tokens: tuple[str, ...]) -> tuple[str, ...]:
    if len(tokens) != 64 or len(set(tokens)) != 64:
        raise RuntimeError("a Sagittarius build needs exactly 64 unique tokens")
    for t in tokens:
        if not t or any(c.isspace() for c in t):
            raise RuntimeError("tokens cannot contain whitespace")
        if any(c in DELIM_CHARS for c in t):
            raise RuntimeError("tokens collide with quote delimiters")
    return tokens


# Violet 1: no ASCII letters or digits. Mathematical operators/glyphs dominate,
# with a small emoji bank. It is intentionally the leanest build.
_VIOLET_SYMBOLS = tuple(
    "∀∂∃∅∆∇∈∉∋∏∑−∓∗∘∙√∝∞∠∧∨∩∪∫∴∵∼≈≠≡≤≥⊂⊃⊄⊆⊇⊕⊗⊙⊥⋄⋆⋈⋮⋯⟂"
) + tuple("⚡☄★✦✧❖✺✹☯☢☣⚙♜♞♠♦")
VIOLET_TOKENS = _check_tokens(_VIOLET_SYMBOLS)


# Sapphire 3: preserve the project's mixed ASCII/operator/glyph/emoji character.
_ASCII_POOL = "0123456789abcdefghijklmnopqrstuvwxyz!#$%&*+-=?@^~/|"
_GLYPHS = [0x2500, 0x2503, 0x254B, 0x2571, 0x2593, 0x25A0, 0x25C6, 0x25CF,
           0x4DC0, 0x4DE9, 0x2801, 0x281B]
_EMOJI = [0x1F300, 0x1F31F, 0x1F340, 0x1F525, 0x1F3B2, 0x1F680,
          0x1F319, 0x26A1, 0x2744, 0x2B50, 0x1F41F, 0x1F3AF]


def _sapphire_tokens() -> tuple[str, ...]:
    ascii_syms = [c for c in _ASCII_POOL if c not in DELIM_CHARS and not c.isspace()][:40]
    points = [ord(c) for c in ascii_syms] + _GLYPHS + _EMOJI
    points.sort(key=lambda cp: hashlib.sha256(
        b"Sagittarius/Sapphire/3/alphabet/" + cp.to_bytes(4, "big")
    ).digest())
    return _check_tokens(tuple(chr(cp) for cp in points))


SAPPHIRE_TOKENS = _sapphire_tokens()


# Parallel 5: each 6-bit value is represented by THREE supplementary-plane
# Unicode codepoints (Egyptian Hieroglyph + Tai Xuan Jing + Alchemical Symbol).
# A token therefore consumes about 12 UTF-8 bytes rather than one ASCII byte.
# This branch is intentionally enormous and visually alien.
PARALLEL_TOKENS = _check_tokens(tuple(
    chr(0x13000 + i) + chr(0x1D300 + i) + chr(0x1F700 + i)
    for i in range(64)
))


VIOLET_1 = BuildSpec(
    family="Violet", version=1, magic=b"SGV1", tokens=VIOLET_TOKENS,
    compression="lzma", junk_ratio=0.35, chunk_size=80, pad_log2=7,
    quote_density=95, wrap_tokens=96, log2n=15,
)

SAPPHIRE_3 = BuildSpec(
    family="Sapphire", version=3, magic=b"SGS3", tokens=SAPPHIRE_TOKENS,
    compression="adaptive", junk_ratio=0.75, chunk_size=96, pad_log2=8,
    quote_density=150, wrap_tokens=0, log2n=17,
)

PARALLEL_5 = BuildSpec(
    family="Parallel", version=5, magic=b"SGP5", tokens=PARALLEL_TOKENS,
    compression="none", junk_ratio=1.50, chunk_size=48, pad_log2=9,
    quote_density=70, wrap_tokens=30, log2n=16,
)

BUILDS = (VIOLET_1, SAPPHIRE_3, PARALLEL_5)
BY_KEY = {(b.family.lower(), b.version): b for b in BUILDS}
BY_MAGIC = {b.magic: b for b in BUILDS}


def resolve_build(family: str | BuildSpec, version: int | None = None) -> BuildSpec:
    if isinstance(family, BuildSpec):
        return family
    text = str(family).strip()
    if version is None:
        parts = text.rsplit(" ", 1)
        if len(parts) == 2 and parts[1].isdigit():
            text, version = parts[0], int(parts[1])
    if version is None:
        candidates = [b for b in BUILDS if b.family.lower() == text.lower()]
        if len(candidates) == 1:
            return candidates[0]
        raise ValueError("build version is required")
    try:
        return BY_KEY[(text.lower(), int(version))]
    except KeyError as exc:
        names = ", ".join(b.short for b in BUILDS)
        raise ValueError(f"unknown Sagittarius build; choose one of: {names}") from exc
