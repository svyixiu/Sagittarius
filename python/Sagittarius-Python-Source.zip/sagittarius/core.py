from __future__ import annotations

import base64
import bz2
import hashlib
import hmac
import json
import lzma
import os
import random
import secrets
import struct
import zlib
from dataclasses import dataclass

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from .builds import BUILDS, BuildSpec, resolve_build
from .quotes import QUOTES, QUOTE_SET, QUOTE_STYLES, OPENERS, normalize_quote


WRONG_KEY_STRICT = "strict"
WRONG_KEY_GIBBERISH = "gibberish"
WRONG_KEY_TAUNT = "taunt"

FORMAT_VERSION = 1
NONCE = 12
TAG = 16
BLOCK_OVERHEAD = NONCE + TAG
FLAG_LAYOUT = 0x01
FLAG_QUOTES = 0x02

# salt, magic, container format version, flags, log2n, r, p, quote_density, pad_log2
HEADER = struct.Struct(">16s4sBBBBBHB")
HEADER_SIZE = HEADER.size

_C_NONE, _C_ZLIB, _C_LZMA, _C_BZ2 = 0, 1, 2, 3
META_PREFIX = struct.Struct(">BBQQIH")

MIN_LOG2N = 14
MAX_LOG2N = 18
MAX_R = 16
MAX_P = 4
MAX_KDF_MEMORY = 512 << 20
MAX_KDF_WORK = (1 << 18) * 16 * 2


class SagittariusError(Exception):
    pass


def _key_bytes(value) -> bytes:
    if isinstance(value, str):
        value = value.encode("utf-8")
    value = bytes(value)
    if not value:
        raise ValueError("master_key must not be empty")
    return value


def _derive_root(master_key, salt: bytes, log2n: int, r: int, p: int) -> bytes:
    n = 1 << log2n
    memory = 128 * n * r
    work = n * r * p
    if memory > MAX_KDF_MEMORY or work > MAX_KDF_WORK:
        raise SagittariusError("scrypt parameters exceed Sagittarius safety budget")
    maxmem = max(32 << 20, 2 * 128 * r * (n + p) + (16 << 20))
    return hashlib.scrypt(_key_bytes(master_key), salt=salt, n=n, r=r, p=p, maxmem=maxmem, dklen=32)


def _derive(root: bytes, spec: BuildSpec, label: bytes) -> bytes:
    return HKDF(
        algorithm=hashes.SHA256(), length=32, salt=None,
        info=spec.domain + b"/" + label,
    ).derive(root)


def _compress(raw: bytes, mode: str) -> tuple[int, bytes]:
    if not raw or mode == "none":
        return _C_NONE, raw
    if mode == "lzma":
        blob = lzma.compress(raw, preset=9 | lzma.PRESET_EXTREME)
        return (_C_LZMA, blob) if len(blob) < len(raw) else (_C_NONE, raw)
    if mode == "zlib":
        blob = zlib.compress(raw, 9)
        return (_C_ZLIB, blob) if len(blob) < len(raw) else (_C_NONE, raw)
    if mode == "adaptive":
        choices = [
            (_C_NONE, raw),
            (_C_ZLIB, zlib.compress(raw, 9)),
            (_C_LZMA, lzma.compress(raw, preset=9 | lzma.PRESET_EXTREME)),
            (_C_BZ2, bz2.compress(raw, 9)),
        ]
        return min(choices, key=lambda item: len(item[1]))
    raise ValueError(f"unknown compression profile: {mode}")


def _decompress(cid: int, blob: bytes, limit: int) -> bytes:
    if cid == _C_NONE:
        out = blob
    elif cid == _C_ZLIB:
        d = zlib.decompressobj(); out = d.decompress(blob, limit + 1)
        if not d.eof:
            raise SagittariusError("incomplete zlib stream")
    elif cid == _C_LZMA:
        d = lzma.LZMADecompressor(); out = d.decompress(blob, limit + 1)
        if not d.eof:
            raise SagittariusError("incomplete lzma stream")
    elif cid == _C_BZ2:
        d = bz2.BZ2Decompressor(); out = d.decompress(blob, limit + 1)
    else:
        raise SagittariusError("unknown compression method")
    if len(out) > limit:
        raise SagittariusError("decompressed size exceeds authenticated size")
    return out


def _make_layout(text: str | None) -> bytes:
    if text is None:
        return b""
    ws = [[i, c] for i, c in enumerate(text) if c in (" ", "\n", "\r", "\t")]
    return zlib.compress(json.dumps({"chars": len(text), "whitespace": ws}, separators=(",", ":")).encode(), 9)


def _read_layout(layout_blob: bytes):
    if not layout_blob:
        return None
    try:
        d = zlib.decompressobj(); raw = d.decompress(layout_blob, 16 << 20)
        if not d.eof:
            return None
        obj = json.loads(raw.decode("utf-8"))
        if not isinstance(obj.get("chars"), int) or not isinstance(obj.get("whitespace"), list):
            return None
        return obj
    except Exception:
        return None


def _pack_blocks(blocks: list[bytes]) -> bytes:
    out = bytearray(struct.pack(">I", len(blocks)))
    for block in blocks:
        out += struct.pack(">I", len(block)) + block
    return bytes(out)


def _unpack_blocks(blob: bytes, offset: int) -> tuple[list[bytes], int]:
    if offset + 4 > len(blob):
        raise SagittariusError("truncated block table")
    count = struct.unpack_from(">I", blob, offset)[0]
    offset += 4
    if count > (len(blob) - offset) // 4:
        raise SagittariusError("block count exceeds payload size")
    blocks = []
    for _ in range(count):
        if offset + 4 > len(blob):
            raise SagittariusError("truncated block length")
        size = struct.unpack_from(">I", blob, offset)[0]
        offset += 4
        if offset + size > len(blob):
            raise SagittariusError("truncated block data")
        blocks.append(blob[offset:offset + size])
        offset += size
    return blocks, offset


def _pack_metadata(comp_id: int, original_size: int, payload_len: int,
                   positions: list[int], chunk_size: int) -> bytes:
    out = bytearray(META_PREFIX.pack(
        FORMAT_VERSION, comp_id, original_size, payload_len, len(positions), chunk_size
    ))
    for pos in positions:
        out += struct.pack(">I", pos)
    return bytes(out)


def _unpack_metadata(blob: bytes):
    if len(blob) < META_PREFIX.size:
        raise SagittariusError("metadata too short")
    version, comp_id, original_size, payload_len, real_count, chunk_size = META_PREFIX.unpack_from(blob, 0)
    if version != FORMAT_VERSION:
        raise SagittariusError("unsupported metadata version")
    need = META_PREFIX.size + real_count * 4
    if need != len(blob):
        raise SagittariusError("metadata position table length mismatch")
    positions = list(struct.unpack_from(f">{real_count}I", blob, META_PREFIX.size)) if real_count else []
    return comp_id, original_size, payload_len, real_count, chunk_size, positions


def _meta_aad(header: bytes, layout_blob: bytes, packed_blocks: bytes) -> bytes:
    return header + hashlib.sha256(layout_blob).digest() + hashlib.sha256(packed_blocks).digest()


def _chunk_aad(spec: BuildSpec, index: int) -> bytes:
    return spec.magic + bytes([FORMAT_VERSION]) + struct.pack(">I", index)


def _whiten(blob: bytes, spec: BuildSpec) -> bytes:
    if len(blob) <= 16:
        return blob
    stream = hashlib.shake_256(spec.domain + b"/whiten/" + blob[:16]).digest(len(blob) - 16)
    return blob[:16] + bytes(a ^ b for a, b in zip(blob[16:], stream))


def _b64_indices(data: bytes) -> list[int]:
    b64 = base64.b64encode(data).rstrip(b"=").decode("ascii")
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    index = {c: i for i, c in enumerate(alphabet)}
    return [index[c] for c in b64]


def _indices_bytes(indices: list[int]) -> bytes:
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    b64 = "".join(alphabet[i] for i in indices).encode("ascii")
    return base64.b64decode(b64 + b"=" * (-len(b64) % 4))


def _match_opener(text: str, i: int) -> int | None:
    for style in OPENERS:
        opener = QUOTE_STYLES[style][0]
        if text.startswith(opener, i):
            return style
    return None


def _quote_count(n_tokens: int, density: int) -> int:
    if n_tokens < 2 or density <= 0:
        return 0
    return max(2, min(n_tokens - 1, n_tokens // density, 600))


def _quote_layout(anchor: bytes, n_tokens: int, density: int) -> list[tuple[int, str, int]]:
    count = _quote_count(n_tokens, density)
    if count <= 0:
        return []
    seed = hmac.new(anchor, b"quotes/" + n_tokens.to_bytes(8, "big") + density.to_bytes(4, "big"), hashlib.sha256).digest()
    rng = random.Random(int.from_bytes(seed, "big"))
    positions = sorted(rng.sample(range(1, n_tokens), count))
    return [(pos, QUOTES[rng.randrange(len(QUOTES))], rng.randrange(len(QUOTE_STYLES))) for pos in positions]


def _quote_anchor(meta_key: bytes, spec: BuildSpec, meta_cipher: bytes) -> bytes:
    return hmac.new(meta_key, spec.domain + b"/quotes/" + meta_cipher[-TAG:], hashlib.sha256).digest()


def _encode_tokens(container: bytes, spec: BuildSpec) -> list[str]:
    return [spec.tokens[i] for i in _b64_indices(container)]


def _weave(tokens: list[str], layout: list[tuple[int, str, int]]) -> list[str]:
    units: list[str] = []
    prev = 0
    for pos, text, style in layout:
        opener, closer = QUOTE_STYLES[style]
        units.extend(tokens[prev:pos])
        units.append(opener + text + closer)
        prev = pos
    units.extend(tokens[prev:])
    return units


def _wrap_units(units: list[str], width_tokens: int) -> str:
    if width_tokens <= 0:
        return "".join(units)
    lines, line, count = [], [], 0
    for unit in units:
        is_quote = _match_opener(unit, 0) is not None
        cost = 0 if is_quote else 1
        if line and count + cost > width_tokens:
            lines.append("".join(line)); line = []; count = 0
        line.append(unit); count += cost
    if line:
        lines.append("".join(line))
    return "\n".join(lines)


def encode_visible(container: bytes, spec: BuildSpec,
                   layout: list[tuple[int, str, int]] | None = None) -> str:
    tokens = _encode_tokens(container, spec)
    units = _weave(tokens, layout or [])
    return _wrap_units(units, spec.wrap_tokens)


def decode_visible(payload: str, spec: BuildSpec) -> tuple[bytes, list[tuple[int, str, int]]]:
    text = payload.strip()
    if not text:
        raise SagittariusError("empty payload")
    token_map = {token: i for i, token in enumerate(spec.tokens)}
    width = spec.token_width
    indices: list[int] = []
    found: list[tuple[int, str, int]] = []
    i = 0
    while i < len(text):
        if text[i].isspace():
            i += 1
            continue
        style = _match_opener(text, i)
        if style is not None:
            opener, closer = QUOTE_STYLES[style]
            j = text.find(closer, i + len(opener))
            if j < 0:
                raise SagittariusError("unterminated quote")
            quote = normalize_quote(text[i + len(opener):j])
            if quote not in QUOTE_SET:
                raise SagittariusError("unknown or altered Sagittarius quote")
            found.append((len(indices), quote, style))
            i = j + len(closer)
            continue
        token = text[i:i + width]
        if token not in token_map:
            raise SagittariusError(f"symbol does not belong to {spec.name}")
        indices.append(token_map[token])
        i += width
    try:
        return _indices_bytes(indices), found
    except Exception as exc:
        raise SagittariusError("invalid encoded Sagittarius payload") from exc


def _looks_like(container: bytes, spec: BuildSpec) -> bool:
    if len(container) < HEADER_SIZE:
        return False
    blob = _whiten(container, spec)
    return blob[16:20] == spec.magic


def detect_payload(payload: str) -> tuple[BuildSpec, bytes, list[tuple[int, str, int]]]:
    matches = []
    for spec in BUILDS:
        try:
            container, found = decode_visible(payload, spec)
            if _looks_like(container, spec):
                matches.append((spec, container, found))
        except SagittariusError:
            continue
    if not matches:
        raise SagittariusError("payload does not match any installed Sagittarius build")
    if len(matches) != 1:
        raise SagittariusError("payload ambiguously matches multiple Sagittarius builds")
    return matches[0]


def _decoy_rng(master_key, blob: bytes, spec: BuildSpec):
    digest = hmac.new(_key_bytes(master_key), spec.domain + b"/decoy/" + hashlib.sha256(blob).digest(), hashlib.sha256).digest()
    return random.Random(int.from_bytes(digest[:16], "big"))


def _make_gibberish(layout, master_key, blob: bytes, spec: BuildSpec) -> str:
    rng = _decoy_rng(master_key, blob, spec)
    if not layout:
        return "".join(rng.choice(spec.tokens) for _ in range(max(32, len(blob) // 3)))
    count = max(0, min(int(layout.get("chars", 0)), 16 << 20))
    whitespace = {}
    for item in layout.get("whitespace", []):
        try:
            idx, ch = int(item[0]), str(item[1])
        except Exception:
            continue
        if 0 <= idx < count and ch in (" ", "\n", "\r", "\t"):
            whitespace[idx] = ch
    # Decoy content is intentionally nonsense and never interpreted as plaintext.
    single = [t for t in spec.tokens if len(t) == 1] or [chr(0xE000 + i) for i in range(64)]
    return "".join(whitespace.get(i) or rng.choice(single) for i in range(count))


def _make_taunt(spec: BuildSpec) -> str:
    return "\n".join((
        f"[{spec.name} Recovery]",
        "Stage 1/5: seed accepted.",
        "Stage 2/5: payload map reconstructed.",
        "Stage 3/5: junk blocks removed.",
        "Stage 4/5: plaintext recovered.",
        "Stage 5/5: you were completely fooled.",
    ))


@dataclass
class Sagittarius:
    build: str | BuildSpec = "Sapphire 3"
    version: int | None = None
    log2n: int | None = None
    r: int | None = None
    p: int | None = None
    quotes: bool = True
    expose_decoy_layout: bool = False

    def __post_init__(self):
        self.spec = resolve_build(self.build, self.version)
        self.log2n = self.spec.log2n if self.log2n is None else int(self.log2n)
        self.r = self.spec.r if self.r is None else int(self.r)
        self.p = self.spec.p if self.p is None else int(self.p)
        if not MIN_LOG2N <= self.log2n <= MAX_LOG2N:
            raise ValueError(f"log2n must be in [{MIN_LOG2N}, {MAX_LOG2N}]")
        if not 1 <= self.r <= MAX_R or not 1 <= self.p <= MAX_P:
            raise ValueError("scrypt r/p outside supported range")
        n = 1 << self.log2n
        if 128 * n * self.r > MAX_KDF_MEMORY or n * self.r * self.p > MAX_KDF_WORK:
            raise ValueError("scrypt settings exceed Sagittarius safety budget")

    @property
    def name(self) -> str:
        return self.spec.name

    def encrypt(self, data, master_key) -> str:
        source_text = data if isinstance(data, str) else None
        source = data.encode("utf-8") if isinstance(data, str) else bytes(data)
        original_size = len(source)
        comp_id, packed_source = _compress(source, self.spec.compression)
        payload_len = len(packed_source)

        # Pad from original size rather than compressed size, so compressibility
        # does not choose the external size bucket.
        bucket = 1 << self.spec.pad_log2
        target = max(bucket, ((original_size // bucket) + 1) * bucket)
        if len(packed_source) > target:
            target = ((len(packed_source) // bucket) + 1) * bucket
        padded = packed_source + os.urandom(target - len(packed_source))

        layout_blob = _make_layout(source_text) if self.expose_decoy_layout else b""
        salt = os.urandom(16)
        flags = (FLAG_LAYOUT if layout_blob else 0) | (FLAG_QUOTES if self.quotes else 0)
        header = HEADER.pack(
            salt, self.spec.magic, FORMAT_VERSION, flags,
            self.log2n, self.r, self.p, self.spec.quote_density, self.spec.pad_log2,
        )

        root = _derive_root(master_key, salt, self.log2n, self.r, self.p)
        enc_key = _derive(root, self.spec, b"content")
        meta_key = _derive(root, self.spec, b"metadata")
        aes = AESGCM(enc_key)

        chunks = [padded[i:i + self.spec.chunk_size] for i in range(0, len(padded), self.spec.chunk_size)] or [b""]
        if len(chunks[-1]) < self.spec.chunk_size:
            chunks[-1] += os.urandom(self.spec.chunk_size - len(chunks[-1]))

        real = []
        for logical, chunk in enumerate(chunks):
            nonce = os.urandom(NONCE)
            real.append(nonce + aes.encrypt(nonce, chunk, _chunk_aad(self.spec, logical)))

        junk_count = round(len(real) * self.spec.junk_ratio)
        if self.spec.junk_ratio > 0 and junk_count == 0:
            junk_count = 1
        junk = [os.urandom(self.spec.chunk_size + BLOCK_OVERHEAD) for _ in range(junk_count)]

        tagged = [(True, i, block) for i, block in enumerate(real)] + [(False, i, block) for i, block in enumerate(junk)]
        secrets.SystemRandom().shuffle(tagged)
        blocks = [item[2] for item in tagged]
        positions = [0] * len(real)
        for physical, (is_real, logical, _) in enumerate(tagged):
            if is_real:
                positions[logical] = physical
        packed_blocks = _pack_blocks(blocks)

        metadata = _pack_metadata(comp_id, original_size, payload_len, positions, self.spec.chunk_size)
        meta_nonce = os.urandom(NONCE)
        meta_cipher = AESGCM(meta_key).encrypt(
            meta_nonce, metadata, _meta_aad(header, layout_blob, packed_blocks)
        )

        raw_container = header + struct.pack(">I", len(layout_blob)) + layout_blob + meta_nonce
        raw_container += struct.pack(">I", len(meta_cipher)) + meta_cipher + packed_blocks
        container = _whiten(raw_container, self.spec)

        quote_layout = []
        if self.quotes:
            n_tokens = len(_b64_indices(container))
            anchor = _quote_anchor(meta_key, self.spec, meta_cipher)
            quote_layout = _quote_layout(anchor, n_tokens, self.spec.quote_density)
        return encode_visible(container, self.spec, quote_layout)

    def _parse(self, blob: bytes, spec: BuildSpec):
        if len(blob) < HEADER_SIZE + 4 + NONCE + 4 + 4:
            raise SagittariusError("payload too short")
        header = blob[:HEADER_SIZE]
        salt, magic, version, flags, log2n, r, p, quote_density, pad_log2 = HEADER.unpack(header)
        if magic != spec.magic:
            raise SagittariusError("build/header mismatch")
        if version != FORMAT_VERSION:
            raise SagittariusError("unsupported Sagittarius container version")
        if flags & ~(FLAG_LAYOUT | FLAG_QUOTES):
            raise SagittariusError("unknown header flags")
        if not MIN_LOG2N <= log2n <= MAX_LOG2N or not 1 <= r <= MAX_R or not 1 <= p <= MAX_P:
            raise SagittariusError("KDF parameters out of range")
        n = 1 << log2n
        if 128 * n * r > MAX_KDF_MEMORY or n * r * p > MAX_KDF_WORK:
            raise SagittariusError("KDF parameters exceed safety budget")
        if quote_density != spec.quote_density or pad_log2 != spec.pad_log2:
            raise SagittariusError("build profile mismatch")

        off = HEADER_SIZE
        if off + 4 > len(blob):
            raise SagittariusError("truncated layout header")
        layout_size = struct.unpack_from(">I", blob, off)[0]; off += 4
        if off + layout_size > len(blob):
            raise SagittariusError("truncated public layout")
        layout_blob = blob[off:off + layout_size]; off += layout_size
        if bool(layout_blob) != bool(flags & FLAG_LAYOUT):
            raise SagittariusError("layout flag mismatch")
        if off + NONCE + 4 > len(blob):
            raise SagittariusError("truncated metadata header")
        meta_nonce = blob[off:off + NONCE]; off += NONCE
        meta_size = struct.unpack_from(">I", blob, off)[0]; off += 4
        if off + meta_size > len(blob):
            raise SagittariusError("truncated metadata")
        meta_cipher = blob[off:off + meta_size]; off += meta_size
        packed_blocks = blob[off:]
        blocks, end = _unpack_blocks(blob, off)
        if end != len(blob):
            raise SagittariusError("unexpected trailing container data")
        return (header, salt, log2n, r, p, flags, layout_blob,
                meta_nonce, meta_cipher, packed_blocks, blocks)

    def decrypt(self, payload: str, master_key, wrong_key_mode: str = WRONG_KEY_STRICT) -> bytes:
        if wrong_key_mode not in (WRONG_KEY_STRICT, WRONG_KEY_GIBBERISH, WRONG_KEY_TAUNT):
            raise ValueError("wrong_key_mode must be strict, gibberish, or taunt")

        spec, container, found = detect_payload(payload)
        blob = _whiten(container, spec)
        (header, salt, log2n, r, p, flags, layout_blob,
         meta_nonce, meta_cipher, packed_blocks, blocks) = self._parse(blob, spec)

        root = _derive_root(master_key, salt, log2n, r, p)
        enc_key = _derive(root, spec, b"content")
        meta_key = _derive(root, spec, b"metadata")

        try:
            meta_plain = AESGCM(meta_key).decrypt(
                meta_nonce, meta_cipher, _meta_aad(header, layout_blob, packed_blocks)
            )
            comp_id, original_size, payload_len, real_count, chunk_size, positions = _unpack_metadata(meta_plain)
        except Exception as exc:
            if wrong_key_mode == WRONG_KEY_GIBBERISH:
                return _make_gibberish(_read_layout(layout_blob), master_key, blob, spec).encode("utf-8")
            if wrong_key_mode == WRONG_KEY_TAUNT:
                return _make_taunt(spec).encode("utf-8")
            raise SagittariusError("wrong key or payload was modified") from exc

        # Presentation binding is checked after successful authentication and is
        # unconditional: decoy mode never disables quote integrity.
        has_quotes = bool(flags & FLAG_QUOTES)
        if has_quotes:
            n_tokens = len(_b64_indices(container))
            anchor = _quote_anchor(meta_key, spec, meta_cipher)
            expected = _quote_layout(anchor, n_tokens, spec.quote_density)
            if found != expected:
                raise SagittariusError("a Sagittarius quote is missing, altered, moved, or re-styled")
        elif found:
            raise SagittariusError("unexpected Sagittarius quote in unquoted payload")

        if chunk_size != spec.chunk_size or real_count != len(positions):
            raise SagittariusError("build chunk profile mismatch")
        if any(pos >= len(blocks) for pos in positions) or len(set(positions)) != len(positions):
            raise SagittariusError("invalid real-block map")

        aes = AESGCM(enc_key)
        recovered = []
        try:
            for logical, physical in enumerate(positions):
                block = blocks[physical]
                if len(block) != spec.chunk_size + BLOCK_OVERHEAD:
                    raise SagittariusError("invalid real block size")
                recovered.append(aes.decrypt(
                    block[:NONCE], block[NONCE:], _chunk_aad(spec, logical)
                ))
        except SagittariusError:
            raise
        except Exception as exc:
            raise SagittariusError("wrong key or payload was modified") from exc

        packed_source = b"".join(recovered)[:payload_len]
        source = _decompress(comp_id, packed_source, original_size)
        if len(source) != original_size:
            raise SagittariusError("recovered size does not match authenticated metadata")
        return source

    def decrypt_text(self, payload: str, master_key, wrong_key_mode: str = WRONG_KEY_STRICT) -> str:
        return self.decrypt(payload, master_key, wrong_key_mode).decode("utf-8")

    @staticmethod
    def identify(payload: str) -> str:
        spec, _, _ = detect_payload(payload)
        return spec.name
