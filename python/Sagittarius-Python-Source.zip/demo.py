from sagittarius import Sagittarius, BUILDS

KEY = "Sagittarius-Demo-Key"
MESSAGE = """local function fib(n)
    if n < 2 then return n end
    return fib(n - 1) + fib(n - 2)
end

for i = 0, 9 do
    print(fib(i))
end"""

for build in BUILDS:
    # demo uses the production build defaults
    engine = Sagittarius(build)
    token = engine.encrypt(MESSAGE, KEY)
    restored = engine.decrypt_text(token, KEY)
    print("=" * 80)
    print(build.name)
    print(f"compression={build.compression} junk_ratio={build.junk_ratio} "
          f"chunk={build.chunk_size} pad=2^{build.pad_log2}")
    print(f"characters={len(token):,} utf8_bytes={len(token.encode('utf-8')):,}")
    print(token)
    print("round_trip:", restored == MESSAGE)
